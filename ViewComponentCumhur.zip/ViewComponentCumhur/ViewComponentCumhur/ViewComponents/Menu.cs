﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ViewComponentCumhur.Models;

namespace ViewComponentCumhur.ViewComponents
{
    public class Menu : ViewComponent
    {
        private readonly CumhurContext cumhurContext;

        public Menu(CumhurContext cumhurContext)
        {
            this.cumhurContext = cumhurContext;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            var anakat = await cumhurContext.AnaKategoris.ToListAsync();
            return View(anakat);
        }
    }
}
