﻿using System;
using System.Collections.Generic;

namespace ViewComponentCumhur.Models;

public partial class AltKategori
{
    public int AltKatId { get; set; }

    public string AltKatAdi { get; set; } = null!;

    public int AnaKatId { get; set; }

    public virtual AnaKategori AnaKat { get; set; } = null!;
}
