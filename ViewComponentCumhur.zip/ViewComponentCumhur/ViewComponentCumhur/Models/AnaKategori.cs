﻿using System;
using System.Collections.Generic;

namespace ViewComponentCumhur.Models;

public partial class AnaKategori
{
    public int AnaKatId { get; set; }

    public string AnaKatAdi { get; set; } = null!;

    public virtual ICollection<AltKategori> AltKategoris { get; } = new List<AltKategori>();

    public List<AltKategori> AltKategori { get; set; }
}
