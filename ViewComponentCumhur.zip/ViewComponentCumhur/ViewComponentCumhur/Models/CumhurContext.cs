﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace ViewComponentCumhur.Models;

public partial class CumhurContext : DbContext
{
    public CumhurContext()
    {

    }

    public CumhurContext(DbContextOptions<CumhurContext> options) : base(options)
    {

    }

    public virtual DbSet<AltKategori> AltKategoris { get; set; } = null!;
    public virtual DbSet<AnaKategori> AnaKategoris { get; set; } = null!;

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<AltKategori>(entity =>
        {
            entity.HasKey(e => e.AltKatId);

            entity.ToTable("AltKategori");

            entity.Property(e => e.AltKatId)
                .HasColumnOrder(0)
                .HasColumnName("AltKatID");
            entity.Property(e => e.AltKatAdi)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnOrder(1);
            entity.Property(e => e.AnaKatId)
                .HasColumnOrder(2)
                .HasColumnName("AnaKatID");

            entity.HasOne(d => d.AnaKat).WithMany(p => p.AltKategoris)
                .HasForeignKey(d => d.AnaKatId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_AltKategori_AnaKategori");
        });

        modelBuilder.Entity<AnaKategori>(entity =>
        {
            entity.HasKey(e => e.AnaKatId);

            entity.ToTable("AnaKategori");

            entity.Property(e => e.AnaKatId)
                .HasColumnOrder(0)
                .HasColumnName("AnaKatID");
            entity.Property(e => e.AnaKatAdi)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnOrder(1);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
